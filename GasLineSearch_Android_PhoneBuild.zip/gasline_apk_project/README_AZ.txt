QAZ XƏTLƏRİ AXTARIŞI — ANDROID APK LAYİHƏSİ

Funksiyalar:
- Ümumi qaz xətləri siyahısında ünvan, xətt kateqoriyası, diametr, il, koordinat və digər sahələr üzrə axtarış.
- Xidmət sahəsi (XS) və diametr üzrə filtr.
- Daşıyıcı qaz xətləri üçün ayrıca siyahı; xətt adı, uzunluq, diametr, təzyiq, QPS və ünvan üzrə axtarış.
- Məlumatlar tətbiqə daxil edilib; internet tələb etmir.

APK yaratmaq:
1. Android Studio-nu kompüterə quraşdırın.
2. Android Studio > Open seçin və bu qovluğu açın: gasline_apk_project
3. Gradle sync tamamlanandan sonra Build > Build Bundle(s) / APK(s) > Build APK(s) seçin.
4. APK adətən app/build/outputs/apk/debug/app-debug.apk yolunda yaranır.
5. APK-nı telefona köçürüb quraşdırın. Telefon quraşdırma zamanı icazə istəyə bilər.

Qeyd: Bu təqdim edilən fayl Android Studio layihəsidir, hazır imzalanmış APK deyil. Buradakı məlumatlar təqdim edilmiş Excel faylından çıxarılıb. İstismar qərarları üçün ilkin Excel sənədi ilə yoxlayın.
